library(tidyverse)
library(readxl)
library(ggplot2)
library(RColorBrewer)
library(svglite)
library(extrafont)
library(scales)
library(cowplot)
library(pals)
library(reshape2)
loadfonts(device = "win")
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
theme_set(theme_get() + theme(text = element_text(family = 'Open Sans')))

#get colour schemes
pal.bands(alphabet, alphabet2, cols25, glasbey, kelly, polychrome, 
          stepped, tol, watlington,
          show.names=FALSE)

#######Figure 1
#####Ascot Data 
data <- read_excel("Data/R_Data_Ascot.xlsx")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#plot ascot data for each restaurant venue, mean with SD error bars
b<-ggplot(data, aes(x=Venue, y=CO2, fill=factor(Day), group=Day)) +
  geom_bar(position=position_dodge(), stat="identity", colour='black') +
  #  scale_fill_manual(values=cbbPalette)+
  scale_fill_manual(values=as.vector(cols25(12)))+
  scale_x_discrete(limit = c("RA1", "RA2", "RA3", "RA4", "RA5", "RA6", "RA7", "RA8", "RA9", "RA10")) +
  ylim(0,1500)+
  labs(y= expression("CO"[2]*" (ppm)"), colour = "Day of event", fill="Day of event")+
  geom_errorbar(aes(ymin=lower, ymax=upper), width=.4,position=position_dodge(0.9))+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=18, colour="black"), 
        axis.text.x=element_text(size=20, colour="black"),
        axis.title.y=element_text(size=20, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16))  


Figure1A <-b

#########Wembley data

data <- read_excel("Data/R_Data_Wembley_Onlyoccupied.xlsx")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#plot Wembley data for each restaurant venue, mean with SD error bars
b<-ggplot(data, aes(x=Venue, y=CO2, fill=factor(Day), group=Day)) +
  geom_bar(position=position_dodge(), stat="identity", colour='black') +
  #  scale_fill_manual(values=cbbPalette)+
  # scale_colour_brewer(palette="Set1") +
  scale_fill_manual(values=as.vector(cols25(12)))+
  scale_x_discrete(limit = c("A8", "A28")) +
  ylim(0,1500)+
  labs(y= expression("CO"[2]*" (ppm)"), colour = "Event ID", fill="Event ID")+
  geom_errorbar(aes(ymin=lower, ymax=upper), width=.4,position=position_dodge(0.9))+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=18, colour="black"), 
        axis.text.x=element_text(size=20, colour="black"),
        axis.title.y=element_text(size=20, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16))  


Figure1B <-b


#Figure1A
#Figure1B

Figure1AB <- plot_grid(Figure1A, Figure1B, ncol=2, rel_widths=c(1, 0.5), 
                       labels=c("a", "b"), label_size=18)


####Figure 2
#####RA5 CO2 data 
AscotRA5 <- read_excel("Data/Rdata_RA5.xlsx")
data <- AscotRA5
dim(data)

a <- ggplot(data, aes(x=aTime,y=CO2,colour=factor(Day), fill=factor(Day)))  + 
  geom_line(linetype=1)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1")+
  ylim(400,1600)

a <- a + geom_ribbon(aes(ymin=lower, ymax=upper, fill=factor(Day)), alpha=0.2, linetype=3)
a <- a + labs(x = "Time (hh:mm)", y= expression("Room average CO"[2]*" (ppm)"), colour = "Day of event", fill="Day of event")
a <- a + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=20, colour="black"), 
        axis.title.x=element_text(size=20, colour="black"),
        legend.text=element_text(size=18),
        legend.title=element_text(size=18))


Figure2A <-a

###########RA7 CO2 data 

AscotRA7 <- read_excel("Data/Rdata_RA7.xlsx")
data <- AscotRA7
dim(data)

a <- ggplot(data, aes(x=aTime,y=CO2,colour=factor(Day), fill=factor(Day)))  + 
  geom_line(linetype=1)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1")+
  ylim(400,1600)

a <- a + geom_ribbon(aes(ymin=lower, ymax=upper, fill=factor(Day)), alpha=0.2, linetype=3)
a <- a + labs(x = "Time (hh:mm)", y= expression("Room average CO"[2]*" (ppm)"), colour = "Day of event", fill="Day of event")
a <- a + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=20, colour="black"), 
        axis.title.x=element_text(size=20, colour="black"),
        legend.text=element_text(size=18),
        legend.title=element_text(size=18))


Figure2B <-a


Figure2AB <- plot_grid(Figure2A, Figure2B, nrow=2, rel_widths=c(1, 1), 
                       labels=c("a", "b"), label_size=26)

#####Figures using MC model
#############MC models

rm(df)

#run the MC for the 20 person office
#assign values and assumptions
A_floor = 200
RoomVolume = 600
N_inf = 1
N_Occupants = 20
ExposureT = 28800
ExposureT_I = 28800
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=154000, sd=15400)
DropletDiameter = 1.84295*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi = 3.333*10^-4
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
#calculate inhaled dose and REI
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/median(Sum_n)
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

Office20Sum_n = median(Sum_n)

#save the REI results for 20 person office
Office20REI = REI
Office20Median = median(REI)
Office20_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)


#using the quartile dose data, calculate the dose response and infector probability, store in data frame
df=data.frame()

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 4.8/3600, 6.8/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for WA8
WA8REI = REI
WA8Median = median(REI)
WA8_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "WA8",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

#plot the dose response curves for office and WA8

#Plot viral load vs dose response
a <- ggplot(df, aes(x=Viral_Load, y=med,colour=factor(room), fill=factor(room)))  + 
  geom_line(linetype=1)+
  scale_x_log10(expand=c(0,0), limits=c(10^6,2*10^12),breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand=c(0,0), labels = function(x) paste0(x, "%"), 
                     sec.axis = sec_axis(~.*(1/3), name="Probability infector has given viral load",
                                         labels = function(x) paste0(x, "%"))
  )

a <- a + geom_ribbon(aes(ymin=lower, ymax=upper, fill=factor(room)), alpha=0.2, linetype=3)
a <- a + labs(x = "Viral load RNA copies/ml", y= expression("Dose curve probability of infection"), colour = "Scenario", fill="Scenario")

a = a +  geom_line(aes(x=Viral_Load,y=Viral_prob*3), linetype=1, show.legend=FALSE, size=1, colour="dark green")

a <- a + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=12, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.text.y.right =  element_text(color = 'dark green'),
        axis.title.y=element_text(size=18, colour="black"), 
        axis.title.y.right =  element_text(color = 'dark green'),
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=18),
        legend.title=element_text(size=20))
Figure10 <-a


#plot the ppi
b <- ggplot(df, aes(x=Viral_Load,y=ppi_med,colour=factor(room), fill=factor(room)))  + 
  geom_line(linetype=1)+
  scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 0.015),breaks=seq(0,0.014,by=0.002), labels = scales::percent)


b <- b + geom_ribbon(aes(ymin=ppi_lower, ymax=ppi_upper, fill=factor(room)), alpha=0.2, linetype=3)
b <- b + labs(x = "Total viral load of infector(s) RNA copies/ml", y= expression("Proportion of people infected for given viral load"), colour = "Scenario", fill="Scenario")
b <- b + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=10, colour="black"), 
        axis.text.x=element_text(size=13, colour="black"),
        axis.title.y=element_text(size=15, colour="black"), 
        axis.title.x=element_text(size=15, colour="black"),
        legend.text=element_text(size=14),
        legend.title=element_text(size=18))
b
Figure11 <-b
##############################
#Figure 6

#Figure6AB <- plot_grid(a, a1, ncol=2, rel_widths=c(1, 0.8), 
 #                      labels=c("a", "b"), label_size=22)
#Figure6AB
#figure6 <- plot_grid(Figure6AB)

#ggsave("Figures/Figure6.pdf", width=15, height=5, dpi=600,device = cairo_pdf)
#ggsave("Figures/Figure6.svg",width=15, height=5, dpi=600)

#Figure 7
#Figure7 <-b
#ggsave("Figures/Figure7.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
#ggsave("Figures/Figure7.svg",width=8, height=5, dpi=600)

#################################

#data for RA1

A_floor = 291
RoomVolume = 1020
N_inf = 1
N_Occupants = 100
ExposureT = 7200
ExposureT_I = 7200
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 4/3600, 5/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for RA1
RA1REI = REI
RA1Median = median(REI)
RA1_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "RA1",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus



#data for RA5

A_floor = 1072
RoomVolume = 4822
N_inf = 1
N_Occupants = 270
ExposureT = 32400
ExposureT_I = 32400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 1.5/3600, 4.5/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for RA5
RA5REI = REI
RA5Median = median(REI)
RA5_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "RA5",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus



#data for RA7

A_floor = 494
RoomVolume = 1236
N_inf = 1
N_Occupants = 112
ExposureT = 32400
ExposureT_I = 32400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 2/3600, 3/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for RA7
RA7REI = REI
RA7Median = median(REI)
RA7_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "RA7",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus



#using the quartile dose data, calculate the dose response and infector probability, store in data frame


#data for Guangzhou

A_floor = 40.5
RoomVolume = 127
N_inf = 1
N_Occupants = 21
ExposureT = 4500
ExposureT_I = 4500
Exposure_T_D = 4500
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=154000, sd=15400)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 0.2/3600, 0.4/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for GUangzhou
GuangzhouREI = REI
GuangzhouMedian = median(REI)
Guangzhou_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "Guangzhou",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

#data for Buonanno model

A_floor = 100
RoomVolume = 300
N_inf = 1
N_Occupants = 84
ExposureT = 10800
ExposureT_I = 10800
Exposure_T_D = 10800
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=154000, sd=15400)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 0.2/3600, 0.2/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/Office20Sum_n
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

#save the REI results for Buonanno
ModelREI = REI
ModelMedian = median(REI)
Model_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "Buonanno model",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus


#using the quartile dose data, calculate the dose response and infector probability, store in data frame


# check str(df)

#font_import(paths = NULL, recursive = TRUE, prompt = TRUE,pattern = NULL)
windowsFonts("Arial" = windowsFont("TT Arial"))








#boxplot ppi data
ThePPI = data.frame()
ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))

dat2 <- t(ThePPI[, c(2:6)])
#bxp(list(stats=dat2, n=rep(10, ncol(dat2))))

#boxplot rei data
#box plot REI data WiP, i'm not happy that the whiskers are not the 2.5% and 97.5% so that I can show 95% CIs

quantiles_95 <- function(x) {
  r <- quantile(x, probs=c(0.025, 0.25, 0.5, 0.75, 0.975))
  names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
  r
}

dfREI <- data.frame(Scenario = factor( rep(c("Office","WA8", "RA1", "RA5","RA7","Guangzhou","Buonanno"), 
                                           each=length(Office20REI))), REI = c(Office20REI,WA8REI,RA1REI,RA5REI,RA7REI,GuangzhouREI,ModelREI))

Figure3 <-ggplot(dfREI, aes(x=REI, y=Scenario, fill=Scenario)) +
  guides(fill=F) +
  coord_flip() +
  stat_summary(fun.data = quantiles_95, geom="boxplot")+
  stat_summary(fun.data = quantiles_95, geom="errorbar", width = 0.1)+
  labs(x="Relative Exposure Index", y="Scenario")+
  scale_x_continuous(limits = c(0, 2.2),breaks=seq(0,2,by=0.5))+
  scale_y_discrete(limits = c("Office","RA1","RA5","RA7","WA8","Guangzhou","Buonanno"))+
  scale_colour_brewer(palette="Set2") +
  scale_fill_brewer(palette="Set2")+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=14, colour="black"), 
        axis.text.x=element_text(size=14, colour="black"),
        axis.title.y=element_text(size=22, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=18),
        legend.title=element_text(size=20))


###try another ppi plot
###Figure5
dfPPI <- data.frame(Scenario = factor( rep(c("Buonanno","Guangzhou","Office","RA1","RA5","RA7","WA8"), 
                                           each=5)), PPI = rep(c(dat2)))
Figure4 <-ggplot(dfPPI, aes(x=PPI, y=Scenario, fill=Scenario)) +
  guides(fill=F) +
  coord_flip() +
  stat_summary(fun.data = quantiles_95, geom="boxplot")+
  stat_summary(fun.data = quantiles_95, geom="errorbar", width = 0.1)+
  labs(x="Proportion of population infected", y="Scenario")+
  scale_x_continuous(limits = c(0, 5),breaks=seq(0,5,by=1), labels = function(x) paste0(x, "%"))+
  scale_y_discrete(limits = c("Office","RA1","RA5","RA7","WA8","Guangzhou","Buonanno"))+
  scale_colour_brewer(palette="Set2") +
  scale_fill_brewer(palette="Set2")+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=14, colour="black"), 
        axis.text.x=element_text(size=14, colour="black"),
        axis.title.y=element_text(size=19, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=18),
        legend.title=element_text(size=20))


#WA8 Ventilation, REI and PPI


#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume



dfW8=data.frame()
df=data.frame()
rm(ThePPI)
for (i in seq(0,550,10)){
  Psi= (i*10)/(1000*RoomVolume)
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/Office20Sum_n
  
  #save the REI results in dataframe
  REI_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  REI_quantile <-append(REI_quantile, 10*i,0)
  REI_quantile <-append(REI_quantile, 1,6)
  dfW8=rbind.data.frame(dfW8, REI_quantile)
  
  #calculate the ppi for each ventilation flow rate
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  rm(DoseProb)
  for (m in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[m]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[m],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[m]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, (i*1),8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","ventilation")
  #dfW8ppi[1:8] <- lapply(dfW8ppi[1:8], as.numeric)
  
  
  
  
}

#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ ventilation, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))


colnames(dfW8)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")
#colnames(ThePPI)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")

rm(c)

#Plot REI vs ventilation rate
c <- ggplot(dfW8, aes(x=Ventilation,y=med,colour=factor(room), fill=factor(room),show.legend = FALSE))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  geom_point(aes(x=2535, y=0.112),
             col = "blue",
             shape = 8,
             size = 3,
             show.legend=FALSE)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 5500)) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 1.4)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))
#       family="Serif"))





c <- c + geom_ribbon(aes(ymin=lower,  ymax=upper, fill=factor(room)),show.legend=FALSE, alpha=0.2, linetype=3)
c <- c + labs(x = "Ventilation rate l/s", y= expression("Relative Exposure Index"))
c <- c + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=22, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )

Figure5A <-c

rm(d)
#Plot PPI vs ventilation rate
d <- ggplot(ThePPI, aes(x=ventilation,y=ppi_med,colour=factor(1), fill=factor(1),show.legend = FALSE))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  geom_point(aes(x=2535, y=1.6),
             col = "blue",
             shape = 4,
             size = 3,
             show.legend=FALSE)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 5500)) +
  #  scale_y_continuous(expand = c(0, 0), limits = c(0, 8)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 8.3),breaks=seq(0,8,by=1), labels = function(x) paste0(x, "%"), )

d <- d + geom_ribbon(aes(ymin=ppi_lower,  ymax=ppi_upper, fill=factor(1)),show.legend=FALSE, alpha=0.2, linetype=3)
d <- d + labs(x = "Ventilation rate l/s", y= expression("Proportion of population infected"))
d <- d + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=19, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )
Figure5B <-d

Figure5AB <- plot_grid(Figure5A, Figure5B, ncol=2, rel_widths=c(1, 1), 
                       labels=c("a", "b"), label_size=22)


#df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
#df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
#df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
#df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
#df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
#df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus



#Dose effect
#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume



dfW8=data.frame()
df=data.frame()
rm(ThePPI)

for (t in 0:2){
  Dose_K = 4100/10^t
  for (i in seq(0,550,10)){
    Psi= (i*10)/(1000*RoomVolume)
    Phi = Psi+Lambda+Gamma+Zeta
    Tau = 1/Phi
    G = V_star*q_inf*C_RNA*N_inf
    n_ss = G/Phi
    nconc_ss = n_ss/RoomVolume
    t_95 = log(0.05)*Tau/3600/24
    Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
    Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
    REI=Sum_n/Office20Sum_n
    
    #save the REI results in dataframe
    REI_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    REI_quantile <-append(REI_quantile, 10*i,0)
    REI_quantile <-append(REI_quantile, 1,6)
    dfW8=rbind.data.frame(dfW8, REI_quantile)
    
    #calculate the ppi for each ventilation flow rate
    ViralLoad = seq(6,12, by = 0.1)
    ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
    CIR = 0.01
    I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
    Psus = (1-CIR)-(1-CIR)^N_Occupants
    rm(DoseProb)
    for (m in 1:61) {
      DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[m]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
      DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
      DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[m],0)
      DoseProb_quantile <-append(DoseProb_quantile, ViralProb[m]*100,6)
      DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
      DoseProb_quantile <-append(DoseProb_quantile, (i*1),8)
      DoseProb_quantile <-append(DoseProb_quantile, Dose_K/10,9)  
      df=rbind.data.frame(df, DoseProb_quantile)
      
    }
    
    colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","ventilation","dose")
    
    
    
    
    
  }
}
#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ ventilation+ dose, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))

e <- ggplot(ThePPI, aes(x=ventilation,y=ppi_med,colour=factor(dose), fill=factor(dose)))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 5500)) +
  #  scale_y_continuous(expand = c(0, 0), limits = c(0, 8)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 21),breaks=seq(0,20,by=2), labels = function(x) paste0(x, "%"), )

e <- e + geom_ribbon(aes(ymin=ppi_lower,  ymax=ppi_upper, fill=factor(dose)), alpha=0.2, linetype=3)
e <- e + labs(x = "Ventilation rate l/s", y= expression("Proportion of population infected"), colour = "Dose k", fill="Dose k")
e <- e + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=22, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )
e
Figure7<-e

######effect of community infection rates
#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 4.8/3600, 6.8/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume



dfW8=data.frame()
df=data.frame()
rm(ThePPI)
for (i in seq(1,1200,1)){

  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/Office20Sum_n
  
  #save the REI results in dataframe
  REI_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  REI_quantile <-append(REI_quantile, i,0)
  REI_quantile <-append(REI_quantile, 1,6)
  dfW8=rbind.data.frame(dfW8, REI_quantile)
  
  #calculate the ppi for each ventilation flow rate
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 1/i
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  rm(DoseProb)
  for (m in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[m]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[m],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[m]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, (i/10),8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","ventilation")
  #dfW8ppi[1:8] <- lapply(dfW8ppi[1:8], as.numeric)
  
  
  
  
}

#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ ventilation, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))


colnames(dfW8)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")
#colnames(ThePPI)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")




#Plot PPI vs community infection rate
f <- ggplot(ThePPI, aes(x=ventilation,y=ppi_med,colour=factor(1), fill=factor(1),show.legend = FALSE))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  geom_point(aes(x=100, y=1.62),
             col = "blue",
             shape = 8,
             size = 3,
             show.legend=FALSE)+
  geom_point(aes(x=440, y=0.444),
             col = "black",
             shape = 18,
             size = 3,
             show.legend=FALSE)+
  geom_point(aes(x=75, y=1.962),
             col = "black",
             shape = 18,
             size = 3,
             show.legend=FALSE)+
  geom_point(aes(x=260, y=0.720),
             col = "black",
             shape = 18,
             size = 3,
             show.legend=FALSE)+
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 1100),breaks=seq(0,1000,by=100)) +
  #  scale_y_continuous(expand = c(0, 0), limits = c(0, 8)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 12),breaks=seq(0,12,by=2), labels = function(x) paste0(x, "%"), )

f <- f + geom_ribbon(aes(ymin=ppi_lower,  ymax=ppi_upper, fill=factor(1)),show.legend=FALSE, alpha=0.2, linetype=3)
f <- f + labs(x = "1/Community Infection Rate", y= expression("Proportion of population infected"))
f <- f + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=19, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )

f
Figure8<-f


######effect of occupancy on infection rates
#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 4.8/3600, 6.8/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume



dfW8=data.frame()
df=data.frame()
rm(ThePPI)
for (i in seq(1,500,1)){
  N_Occupants = i
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/Office20Sum_n
  
  #save the REI results in dataframe
  REI_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  REI_quantile <-append(REI_quantile, i,0)
  REI_quantile <-append(REI_quantile, 1,6)
  dfW8=rbind.data.frame(dfW8, REI_quantile)
  
  #calculate the ppi for each ventilation flow rate
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  rm(DoseProb)
  for (m in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[m]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[m],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[m]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, (i/10),8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","ventilation")
  #dfW8ppi[1:8] <- lapply(dfW8ppi[1:8], as.numeric)
  
  # write.csv(unique(df$P_sus),file="Psus.csv")
  
  
}

#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ ventilation, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))


colnames(dfW8)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")
#colnames(ThePPI)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")




#Plot PPI vs community infection rate
f <- ggplot(ThePPI, aes(x=ventilation,y=ppi_med,colour=factor(1), fill=factor(1),show.legend = FALSE))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  geom_point(aes(x=210, y=1.587),
             col = "blue",
             shape = 8,
             size = 3,
             show.legend=FALSE)+

  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 510),breaks=seq(0,500,by=50)) +
  #  scale_y_continuous(expand = c(0, 0), limits = c(0, 8)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 5.4),breaks=seq(0,5,by=1), labels = function(x) paste0(x, "%"), )

f <- f + geom_ribbon(aes(ymin=ppi_lower,  ymax=ppi_upper, fill=factor(1)),show.legend=FALSE, alpha=0.2, linetype=3)
f <- f + labs(x = "Occupancy", y= expression("Proportion of population infected"))
f <- f + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=19, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )

f
Figure6A<-f

######effect of occupancy on infection rates, if space volume and per person flow rate increase
#data for WA8

A_floor = 630
RoomVolume = 1575
N_inf = 1
N_Occupants = 210
ExposureT = 14400
ExposureT_I = 14400
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=232400, sd=23240)
DropletDiameter = 1.92481383208094*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi= runif(10000, 4.8/3600, 6.8/3600)
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume



dfW8=data.frame()
df=data.frame()
rm(ThePPI)
for (i in seq(1,500,1)){
  N_Occupants = i
  RoomVolume = i*7.5
  Psi = ((i*10*3.6)/RoomVolume)/3600
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/Office20Sum_n
  
  #save the REI results in dataframe
  REI_quantile = quantile(REI,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  REI_quantile <-append(REI_quantile, i,0)
  REI_quantile <-append(REI_quantile, 1,6)
  dfW8=rbind.data.frame(dfW8, REI_quantile)
  
  #calculate the ppi for each ventilation flow rate
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  rm(DoseProb)
  for (m in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[m]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[m],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[m]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, (i/10),8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","ventilation")
  #dfW8ppi[1:8] <- lapply(dfW8ppi[1:8], as.numeric)
  
  # write.csv(unique(df$P_sus),file="Psus.csv")
  
  
}

#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ ventilation, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))


colnames(dfW8)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")
#colnames(ThePPI)<-c("Ventilation","lower","l_quarter","med","u_quarter","upper","room")




#Plot PPI vs community infection rate
g <- ggplot(ThePPI, aes(x=ventilation,y=ppi_med,colour=factor(1), fill=factor(1),show.legend = FALSE))  + 
  geom_line(linetype=1,show.legend=FALSE)+
  geom_point(aes(x=210, y=1.587),
             col = "blue",
             shape = 8,
             size = 3,
             show.legend=FALSE)+
  
  scale_colour_brewer(palette="Set1") +
  scale_fill_brewer(palette="Set1") +
  #set the origin to zero and set the limits of x and y axis
  scale_x_continuous(expand = c(0, 0), limits = c(0, 510),breaks=seq(0,500,by=50)) +
  #  scale_y_continuous(expand = c(0, 0), limits = c(0, 8)) +
  theme(text=element_text(size=16, 
                          #       family="Comic Sans MS"))
                          #       family="CM Roman"))
                          #       family="TT Times New Roman"))
                          family="TT Ariel"))+
  #       family="Serif"))
  
  scale_y_continuous(expand = c(0, 0), limits = c(0, 5.4),breaks=seq(0,5,by=1), labels = function(x) paste0(x, "%"), )

g <- g + geom_ribbon(aes(ymin=ppi_lower,  ymax=ppi_upper, fill=factor(1)),show.legend=FALSE, alpha=0.2, linetype=3)
g <- g + labs(x = "Occupancy", y= expression("Proportion of population infected"))
g <- g + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"),
        axis.text.y=element_text(size=16, colour="black"), 
        axis.text.x=element_text(size=18, colour="black"),
        axis.title.y=element_text(size=19, colour="black"), 
        axis.title.x=element_text(size=22, colour="black")
  )

g
Figure6B<-g

Figure6AB <- plot_grid(Figure6A, Figure6B, ncol=2, rel_widths=c(1, 1), 
                       labels=c("a", "b"), label_size=22)

#################heat map figure for WA8


#############get relative values

rm(df)
rm(DoseProb)
#run the MC for the 20 person office
#assign values and assumptions
A_floor = 200
RoomVolume = 600
N_inf = 1
N_Occupants = 20
ExposureT = 28800
ExposureT_I = 28800
Exposure_T_D = 0
LungDepositionK = runif(10000,0.43,0.63)
q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
q_inf = q_sus
q_bar = q_sus
C_drop = rnorm(10000, mean=154000, sd=15400)
DropletDiameter = 1.84295*10^-6
Droplet_SD = DropletDiameter/10
DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
Psi = 3.333*10^-4
m <- 0.63/3600
s <- 0.43/3600
Lambdam <- log(m^2 / sqrt(s^2 + m^2))
Lambdas <- sqrt(log(1 + (s^2 / m^2)))
Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
Gamma = runif(10000,0.000117, 0.000169)
C_RNA = 3*10^15*125
Dose_K = 410
Virions = 1
V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
Phi = Psi+Lambda+Gamma+Zeta
Tau = 1/Phi
G = V_star*q_inf*C_RNA*N_inf
#calculate inhaled dose and REI
n_ss = G/Phi
nconc_ss = n_ss/RoomVolume
t_95 = log10(0.05)*Tau/3600/24
Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
REI=Sum_n/median(Sum_n)
ViralLoad = seq(6,12, by = 0.1)
ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
CIR = 0.01
I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
Psus = (1-CIR)-(1-CIR)^N_Occupants

OfficeREIdefault = median(Sum_n)

#using the quartile dose data, calculate the dose response and infector probability, store in data frame
df=data.frame()

for (i in 1:61) {
  DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
  DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
  DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
  DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
  DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
  DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
  
  df=rbind.data.frame(df, DoseProb_quantile)
  
}

colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
df[1:8] <- lapply(df[1:8], as.numeric)


#calculate the ppi for each viral load
df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus

ThePPI = data.frame()
ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)

ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))

dat2 <- t(ThePPI[, c(2:6)])

OfficePPIdefault = dat2[[3]]


#############MC models
Multiplier <- c(1/(1.2)^8,1/(1.2)^7,1/(1.2)^6,1/(1.2)^5,1/(1.2)^4,1/(1.2)^3,1/(1.2)^2,1/(1.2)^1,1,1*(1.2)^1,1*(1.2)^2,1*(1.2)^3,1*(1.2)^4,1*(1.2)^5,1*(1.2)^6,1*(1.2)^7,1*(1.2)^8)
rm(df)
WA8REI = data.frame(matrix(nrow=1))
WA8PPI = data.frame(matrix(nrow=1))

####Room Volume

for(mp in 1:17) {
  #run the MC for the 20 person office
  #assign values and assumptions
  A_floor = 630
  RoomVolume = 1575 * Multiplier[mp]
  N_inf = 1
  N_Occupants = 210
  ExposureT = 14400
  ExposureT_I = 14400
  Exposure_T_D = 0
  LungDepositionK = runif(10000,0.43,0.63)
  q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
  q_inf = q_sus
  q_bar = q_sus
  C_drop = rnorm(10000, mean=232400, sd=23240)
  DropletDiameter = 1.92481383208094*10^-6
  Droplet_SD = DropletDiameter/10
  DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
  Psi = (2.535/RoomVolume) 
  m <- 0.63/3600
  s <- 0.43/3600
  Lambdam <- log(m^2 / sqrt(s^2 + m^2))
  Lambdas <- sqrt(log(1 + (s^2 / m^2)))
  Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
  Gamma = runif(10000,0.000117, 0.000169)
  C_RNA = 3*10^15*125
  Dose_K = 410
  Virions = 1
  V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  #calculate inhaled dose and REI
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log10(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/median(Sum_n)
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  
  WA8Sum_n = median(Sum_n)/OfficeREIdefault
  
  
  
  
  #using the quartile dose data, calculate the dose response and infector probability, store in data frame
  df=data.frame()
  
  for (i in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
  df[1:8] <- lapply(df[1:8], as.numeric)
  
  
  #calculate the ppi for each viral load
  df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus
  
  ThePPI = data.frame()
  ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)
  
  ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))
  
  dat2 <- t(ThePPI[, c(2:6)])
  
  WA8REI <-cbind(WA8REI,WA8Sum_n)
  WA8PPI <-cbind(WA8PPI,dat2[[3]]/OfficePPIdefault)
  
}
names(WA8REI) <- c("variable", "0.23", "0.28", "0.33", "0.40", "0.48", "0.58", "0.69", "0.83","1.00","1.20","1.44","1.73","2.07","2.49","2.99","3.58","4.30")
names(WA8PPI) <- c("variable", "0.23", "0.28", "0.33", "0.40", "0.48", "0.58", "0.69", "0.83","1.00","1.20","1.44","1.73","2.07","2.49","2.99","3.58","4.30")

WA8REI[1,1] <- "Room Volume"
WA8PPI[1,1] <- "Room Volume"


#####occupancy
add_row(WA8REI)
add_row(WA8PPI)
for(mp in 1:17) {
  #run the MC for the 20 person office
  #assign values and assumptions
  A_floor = 630
  RoomVolume = 1575 
  N_inf = 1
  N_Occupants = 210 * Multiplier[mp]
  ExposureT = 14400
  ExposureT_I = 14400
  Exposure_T_D = 0
  LungDepositionK = runif(10000,0.43,0.63)
  q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
  q_inf = q_sus
  q_bar = q_sus
  C_drop = rnorm(10000, mean=232400, sd=23240)
  DropletDiameter = 1.92481383208094*10^-6
  Droplet_SD = DropletDiameter/10
  DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
  Psi = 2.535/RoomVolume
  m <- 0.63/3600
  s <- 0.43/3600
  Lambdam <- log(m^2 / sqrt(s^2 + m^2))
  Lambdas <- sqrt(log(1 + (s^2 / m^2)))
  Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
  Gamma = runif(10000,0.000117, 0.000169)
  C_RNA = 3*10^15*125
  Dose_K = 410
  Virions = 1
  V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  #calculate inhaled dose and REI
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log10(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/median(Sum_n)
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  
  WA8Sum_n = median(Sum_n)/OfficeREIdefault
  
  
  
  
  #using the quartile dose data, calculate the dose response and infector probability, store in data frame
  df=data.frame()
  
  for (i in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
  df[1:8] <- lapply(df[1:8], as.numeric)
  
  
  #calculate the ppi for each viral load
  df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus
  
  ThePPI = data.frame()
  ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)
  
  ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))
  
  dat2 <- t(ThePPI[, c(2:6)])
  
  WA8REI[2,mp+1] = WA8Sum_n
  WA8PPI[2,mp+1] = dat2[[3]]/OfficePPIdefault
  
}

WA8REI[2,1] <- "Occupancy"
WA8PPI[2,1] <- "Occupancy"

#####exposure time
add_row(WA8REI)
add_row(WA8PPI)
for(mp in 1:17) {
  #run the MC for the 20 person office
  #assign values and assumptions
  A_floor = 630
  RoomVolume = 1575 
  N_inf = 1
  N_Occupants = 210
  ExposureT = 14400 * Multiplier[mp]
  ExposureT_I = 14400 * Multiplier[mp]
  Exposure_T_D = 0
  LungDepositionK = runif(10000,0.43,0.63)
  q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
  q_inf = q_sus
  q_bar = q_sus
  C_drop = rnorm(10000, mean=232400, sd=23240)
  DropletDiameter = 1.92481383208094*10^-6
  Droplet_SD = DropletDiameter/10
  DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
  Psi = 2.535/RoomVolume
  m <- 0.63/3600
  s <- 0.43/3600
  Lambdam <- log(m^2 / sqrt(s^2 + m^2))
  Lambdas <- sqrt(log(1 + (s^2 / m^2)))
  Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
  Gamma = runif(10000,0.000117, 0.000169)
  C_RNA = 3*10^15*125
  Dose_K = 410
  Virions = 1
  V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  #calculate inhaled dose and REI
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log10(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/median(Sum_n)
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  
  WA8Sum_n = median(Sum_n)/OfficeREIdefault
  
  
  
  
  #using the quartile dose data, calculate the dose response and infector probability, store in data frame
  df=data.frame()
  
  for (i in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
  df[1:8] <- lapply(df[1:8], as.numeric)
  
  
  #calculate the ppi for each viral load
  df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus
  
  ThePPI = data.frame()
  ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)
  
  ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))
  
  dat2 <- t(ThePPI[, c(2:6)])
  
  WA8REI[3,mp+1] = WA8Sum_n
  WA8PPI[3,mp+1] = dat2[[3]]/OfficePPIdefault
  
}

WA8REI[3,1] <- "Exposure Time"
WA8PPI[3,1] <- "Exposure Time"

#####Ventilation
add_row(WA8REI)
add_row(WA8PPI)
for(mp in 1:17) {
  #run the MC for the 20 person office
  #assign values and assumptions
  A_floor = 630
  RoomVolume = 1575 
  N_inf = 1
  N_Occupants = 210
  ExposureT = 14400 
  ExposureT_I = 14400
  Exposure_T_D = 0
  LungDepositionK = runif(10000,0.43,0.63)
  q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
  q_inf = q_sus
  q_bar = q_sus
  C_drop = rnorm(10000, mean=232400, sd=23240)
  DropletDiameter = 1.92481383208094*10^-6
  Droplet_SD = DropletDiameter/10
  DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
  Psi = (2.535/RoomVolume) * Multiplier[mp]
  m <- 0.63/3600
  s <- 0.43/3600
  Lambdam <- log(m^2 / sqrt(s^2 + m^2))
  Lambdas <- sqrt(log(1 + (s^2 / m^2)))
  Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
  Gamma = runif(10000,0.000117, 0.000169)
  C_RNA = 3*10^15*125
  Dose_K = 410
  Virions = 1
  V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  #calculate inhaled dose and REI
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log10(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/median(Sum_n)
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  
  WA8Sum_n = median(Sum_n)/OfficeREIdefault
  
  
  
  
  #using the quartile dose data, calculate the dose response and infector probability, store in data frame
  df=data.frame()
  
  for (i in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
  df[1:8] <- lapply(df[1:8], as.numeric)
  
  
  #calculate the ppi for each viral load
  df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus
  
  ThePPI = data.frame()
  ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)
  
  ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))
  
  dat2 <- t(ThePPI[, c(2:6)])
  
  WA8REI[4,mp+1] = WA8Sum_n
  WA8PPI[4,mp+1] = dat2[[3]]/OfficePPIdefault
  
}

WA8REI[4,1] <- "Ventilation"
WA8PPI[4,1] <- "Ventilation"

#####CIR
add_row(WA8REI)
add_row(WA8PPI)
for(mp in 1:17) {
  #run the MC for the 20 person office
  #assign values and assumptions
  A_floor = 630
  RoomVolume = 1575 
  N_inf = 1
  N_Occupants = 210
  ExposureT = 14400 
  ExposureT_I = 14400
  Exposure_T_D = 0
  LungDepositionK = runif(10000,0.43,0.63)
  q_sus = rnorm(10000, mean=9.3/1000/60, sd = 0.93/1000/60)
  q_inf = q_sus
  q_bar = q_sus
  C_drop = rnorm(10000, mean=232400, sd=23240)
  DropletDiameter = 1.92481383208094*10^-6
  Droplet_SD = DropletDiameter/10
  DropletDia = rnorm(10000, mean = DropletDiameter, sd = Droplet_SD)
  Psi = 2.535/RoomVolume 
  m <- 0.63/3600
  s <- 0.43/3600
  Lambdam <- log(m^2 / sqrt(s^2 + m^2))
  Lambdas <- sqrt(log(1 + (s^2 / m^2)))
  Lambda = rlnorm(10000,mean=Lambdam,sd=Lambdas)
  Gamma = runif(10000,0.000117, 0.000169)
  C_RNA = 3*10^15*125
  Dose_K = 410
  Virions = 1
  V_star = (4/3)*pi*((DropletDia/2)^3)*C_drop
  Zeta = (N_Occupants*q_bar*LungDepositionK)/RoomVolume
  Phi = Psi+Lambda+Gamma+Zeta
  Tau = 1/Phi
  G = V_star*q_inf*C_RNA*N_inf
  #calculate inhaled dose and REI
  n_ss = G/Phi
  nconc_ss = n_ss/RoomVolume
  t_95 = log10(0.05)*Tau/3600/24
  Term1 = (LungDepositionK*q_sus*G)/(Phi^2*RoomVolume)
  Sum_n = Term1*(ExposureT*Phi+exp(-Phi*ExposureT)-1)
  REI=Sum_n/median(Sum_n)
  ViralLoad = seq(6,12, by = 0.1)
  ViralProb = dnorm(ViralLoad, mean = 7, sd = 1.4)
  CIR = 0.01* Multiplier[mp]
  I_Bar = (CIR*N_Occupants)/(1-(1-CIR)^N_Occupants)
  Psus = (1-CIR)-(1-CIR)^N_Occupants
  
  WA8Sum_n = median(Sum_n)/OfficeREIdefault
  
  
  
  
  #using the quartile dose data, calculate the dose response and infector probability, store in data frame
  df=data.frame()
  
  for (i in 1:61) {
    DoseProb =100*( 1-exp(-(((LungDepositionK*q_sus*10^ViralLoad[i]*125000000*Virions*V_star*q_inf)/(Phi^2*RoomVolume))*(ExposureT*Phi+exp(-Phi*ExposureT)-1)*I_Bar/Dose_K)))
    DoseProb_quantile = quantile(DoseProb,probs=c(0.025,0.25,0.5,0.75,0.975), names=FALSE)
    DoseProb_quantile <-append(DoseProb_quantile, 10^ViralLoad[i],0)
    DoseProb_quantile <-append(DoseProb_quantile, ViralProb[i]*100,6)
    DoseProb_quantile <-append(DoseProb_quantile, Psus,7)
    DoseProb_quantile <-append(DoseProb_quantile, "Office",8)
    
    df=rbind.data.frame(df, DoseProb_quantile)
    
  }
  
  colnames(df)<-c("Viral_Load","lower","l_quarter","med","u_quarter","upper","Viral_prob","P_sus","room")
  df[1:8] <- lapply(df[1:8], as.numeric)
  
  
  #calculate the ppi for each viral load
  df$ppi_lower<-(df$lower/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_l_quarter<-(df$l_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_med<-(df$med/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_u_quarter<-(df$u_quarter/100)*(df$Viral_prob/100)*df$P_sus
  df$ppi_upper<-(df$upper/100)*(df$Viral_prob/100)*df$P_sus
  
  ThePPI = data.frame()
  ThePPI <- aggregate(cbind(ppi_lower, ppi_l_quarter, ppi_med, ppi_u_quarter, ppi_upper) ~ room, df, sum)
  
  ThePPI[] = lapply(ThePPI, FUN = function(x) if (is.numeric(x)) return(x * 10) else return(x))
  
  dat2 <- t(ThePPI[, c(2:6)])
  
  WA8REI[5,mp+1] = WA8Sum_n
  WA8PPI[5,mp+1] = dat2[[3]]/OfficePPIdefault
  
}

WA8REI[5,1] <- "CIR"
WA8PPI[5,1] <- "CIR"

#########################plot heat map


a = WA8REI %>%
  pivot_longer(!variable, names_to = "Multiplier", values_to = "REI") %>%
  mutate(Multiplier =factor(as.numeric(Multiplier)))

Figure9A <- ggplot(a, aes(variable, Multiplier, fill= REI)) + 
  geom_tile() +
  scale_y_discrete(labels = function(x) sprintf("%.2f", as.numeric(x))) +
  scale_fill_gradient2( low="white", mid="red", high="black", midpoint = 0.11, limits=c(NA,0.5), breaks=c(0,0.1,0.2,0.3,0.5),trans = 'log', label = function(x) sprintf("%.2f", x))+
  theme(axis.text.y=element_text(size=14, colour="black"), 
        axis.text.x=element_text(size=12, colour="black"),
        axis.title.y=element_text(size=22, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=12),
        legend.title=element_text(size=16)) 
#  geom_text(
#    aes(variable, Multiplier, label=sprintf("%0.2f", round(REI, digits = 2)))
#  ) 
Figure9A

b = WA8PPI %>%
  pivot_longer(!variable, names_to = "Multiplier", values_to = "PPI") %>%
  mutate(Multiplier =factor(as.numeric(Multiplier)))
Figure9B <- ggplot(b, aes(variable, Multiplier, fill= PPI)) + 
  geom_tile() + 
  scale_y_discrete(labels = function(x) sprintf("%.2f", as.numeric(x))) +
  scale_fill_gradient2( low="white", mid="red", high="black", midpoint = 1, limits=c(NA,7), breaks=c(0,0.1,0.2,0.5,1,2,3,5,7), trans = 'log', label = function(x) sprintf("%.2f", x), name = "TR" )+
  theme(axis.text.y=element_text(size=14, colour="black"), 
        axis.text.x=element_text(size=12, colour="black"),
        axis.title.y=element_text(size=22, colour="black"), 
        axis.title.x=element_text(size=22, colour="black"),
        legend.text=element_text(size=12),
        legend.title=element_text(size=16)) 
#  geom_text(
#    aes(variable, Multiplier, label=sprintf("%0.1f", round(PPI, digits = 1)))
#  ) 

Figure9AB <- plot_grid(Figure9A,NA, Figure9B, ncol=3, rel_widths=c(1,0.15, 1), 
                       labels=c("a","", "b"), label_size=22)

Figure9AB

######save all figures
#Figure1
Figure1AB

ggsave("Figures/Figure1.pdf", width=18, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure1.svg",width=18, height=5, dpi=600)
ggsave("Figures/Figure1.png",width=18, height=5, dpi=600)


#Figure2
Figure2AB
ggsave("Figures/Figure2.pdf", device = cairo_pdf, width=15, height=10, dpi=600)
ggsave("Figures/Figure2.png", width=15, height=10, dpi=600)
ggsave("Figures/Figure2.svg", width=15, height=10, dpi=600)

#Figure3
Figure3
ggsave("Figures/Figure3.pdf", device = cairo_pdf, width=8, height=5, dpi=600)
ggsave("Figures/Figure3.png", width=8, height=5, dpi=600)
ggsave("Figures/Figure3.svg", width=8, height=5, dpi=600)

#Figure 4
Figure4
ggsave("Figures/Figure4.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure4.svg",width=8, height=5, dpi=600)
ggsave("Figures/Figure4.png",width=8, height=5, dpi=600)

#Figure 5
Figure5AB
ggsave("Figures/Figure5.pdf", width=15, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure5.svg",width=15, height=5, dpi=600)
ggsave("Figures/Figure5.png",width=15, height=5, dpi=600)

#Figure6
Figure6AB
ggsave("Figures/Figure6.pdf", width=15, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure6.svg",width=15, height=5, dpi=600)
ggsave("Figures/Figure6.png",width=15, height=5, dpi=600)

#Figure 7
Figure7
ggsave("Figures/Figure7.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure7.svg",width=8, height=5, dpi=600)
ggsave("Figures/Figure7.png",width=8, height=5, dpi=600)

#Figure8
Figure8
ggsave("Figures/Figure8.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure8.svg",width=8, height=5, dpi=600)
ggsave("Figures/Figure8.png",width=8, height=5, dpi=600)

#Figure9
Figure9AB
ggsave("Figures/Figure9AB.pdf", width=16, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure9AB.svg",width=15, height=5, dpi=600)
ggsave("Figures/Figure9AB.png",width=15, height=5, dpi=600)

#Figure10
Figure10
ggsave("Figures/Figure10.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure10.svg",width=8, height=5, dpi=600)
ggsave("Figures/Figure10.png",width=8, height=5, dpi=600)

#Figure11
Figure11
ggsave("Figures/Figure11.pdf", width=8, height=5, dpi=600,device = cairo_pdf)
ggsave("Figures/Figure11.svg",width=8, height=5, dpi=600)
ggsave("Figures/Figure11.png",width=8, height=5, dpi=600)
